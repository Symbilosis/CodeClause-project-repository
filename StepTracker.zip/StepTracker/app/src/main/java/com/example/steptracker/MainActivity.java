package com.example.steptracker;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private TextView txt1, txt2, txt3;
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private boolean isAccelerometerPresent;
    private float previousY;
    Button btnStop, btnReset;
    private static final float STEPS_TO_CALORIES_FACTOR = 0.05f;
    private int stepCount = 0;
    private boolean isCounting = true;
    private static final float STEPS_TO_DISTANCE_FACTOR = 0.762f;
    private static final float AVERAGE_STRIDE_LENGTH = 0.7f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        txt1 = findViewById(R.id.tv1);
        txt2 = findViewById(R.id.tv5);
        txt3 = findViewById(R.id.tv6);
        btnStop = findViewById(R.id.stp);
        btnReset = findViewById(R.id.res);





        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        if (sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            isAccelerometerPresent = true;
        } else {
            txt1.setText("Accelerometer Sensor is absent");
            isAccelerometerPresent = false;
        }


        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isCounting = !isCounting;
                if (isCounting) {
                    btnStop.setText("Stop");
                    Toast.makeText(MainActivity.this, "It's green Woohooo", Toast.LENGTH_SHORT).show();


                } else {
                    btnStop.setText("Start");
                    Toast.makeText(MainActivity.this, "Waiting for Red Light to turn Green??", Toast.LENGTH_SHORT).show();


                }


            }
        });


        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stepCount = 0;
                txt1.setText(String.valueOf(stepCount));
                Toast.makeText(MainActivity.this, "Back to the Beginning", Toast.LENGTH_SHORT).show();

            }
        });
    }


    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor == accelerometer) {
            float caloriesBurned = stepCount * STEPS_TO_CALORIES_FACTOR;
            txt2.setText(String.format("%.2f Kcal", caloriesBurned));
            float distance = stepCount * AVERAGE_STRIDE_LENGTH * STEPS_TO_DISTANCE_FACTOR;
            txt3.setText(String.format("%.2f meters", distance));
            float currentY = sensorEvent.values[1];

            if (isStep(currentY, previousY)) {
                stepCount++;
                txt1.setText(String.valueOf(stepCount));
            }
            previousY = currentY;
        }
    }

    private boolean isStep(float currentY, float previousY) {
        if (previousY > 0 && currentY < 0) {
            return true;
        }
        return false;
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null) {
            sensorManager.unregisterListener(this, accelerometer);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {
        // Not used in this example
    }




}